// AOS init
function aos_init() {
    AOS.init({
        duration: 1000,
        easing: "ease-in-out",
        once: true,
        mirror: false
    })
}

window.addEventListener('load', () => {
    aos_init();
  });

// calculate age
function calculateAge() {
    var birthdayInput = document.getElementById("birthdayInput").value;
    var today = new Date();
    var birthDate = new Date(birthdayInput);
    var age = today.getFullYear() - birthDate.getFullYear();
    var monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    document.getElementById("ageInput").value = age;
}
